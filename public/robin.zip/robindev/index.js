var pidgon = require("./script/index");
var noomber = require("./script/noomber");
var chokidar = require("chokidar");
var fs = require("fs");
console.log(
  "Robin is open! Run robin run <filename.robin> to start your file!"
);
noomber.make("connectedFiles", "");
pidgon.linequestion((answer) => {
  if (answer.startsWith("robin run")) {
    chokidar.watch(answer.split(" ")[2]).on("all", (event, path) => {
      console.log(
        `\n--- Robin file restarting. Timestamp: ${pidgon.hms()} ${pidgon.period()} ---\n`
      );

      robinEval(answer.split(" ")[2]);
    });
  } else console.log("robin: that command doesn't exist.");
});

function robinEval(filename) {
  noomber.make("currentfile", filename);
  fs.readFile(filename, function (err, data) {
    if (err) {
      throw "robin: mainfile error: " + err;
    }
    var content =
      `var pidgon = require("pidgonscript");\n
       var noomber = require("pidgonscript/noomber");\n` +
      //otherFileData +
      data.toString();

    eval(
      content
        //variables, printing
        .replace(/set /g, "var ")
        .replace(/print/g, "console.log(")
        .replace(/to the console/g, ");")
        //equalities
        .replace(/is greater than/g, ">")
        .replace(/is lesser than/g, "<")
        .replace(/is equal to/g, "==")
        .replace(/is greater than or equal to/g, ">=")
        .replace(/is lesser than or equal to/g, "<=")
        //operations
        .replace(/\$add/g, "pidgon.adds(")
        .replace(/\$subtract/g, "pidgon.subtracts(")
        .replace(/\$divide/g, "pidgon.divides(")
        .replace(/\$multiply/g, "pidgon.multiplies(")
        .replace(/\$get a random number from/g, "pidgon.random(")
        .replace(/\$the square root of \$/g, "pidgon.sqrt(")
        //if else
        .replace(/if \$/g, "if(")
        .replace(/otherwise,/g, "} else {")
        //functions
        .replace(/create a function /g, "function ")
        .replace(/which takes /g, "(")
        .replace(/then d/g, ") {")
        .replace(/which will/g, "() {")
        .replace(/start /g, "")
        .replace(/ please/g, "()")
        .replace(/ with values of \$/g, "(")
        //delays
        .replace(/create a delay of /g, "pidgon.delay(")
        .replace(/then/g, ", then => {")
        .replace(/finish/g, "})")
        //datetime
        .replace(/the time right now/g, "pidgon.hms()")
        .replace(/the period right now/g, "pidgon.period()")
        .replace(/the second right now/g, "pidgon.second()")
        .replace(/the minute right now/g, "pidgon.minute()")
        .replace(/the date right now/g, "pidgon.date()")
        .replace(/the day right now/g, "pidgon.day()")
        .replace(/the year right now/g, "pidgon.year()")
        .replace(/the name of the month right now/g, "pidgon.monthname()")
        .replace(/the number of the month right now/g, "pidgon.monthnumber()")
        //encrypt
        .replace(/\$encrypt \$/g, "pidgon.encrypt(")
        .replace(/\$decrypt \$/g, "pidgon.decrypt(")
        .replace(/use package \$/g, "require(")
        //hosting
        .replace(/create a text server that says /g, "pidgon.textserver(")
        .replace(/ at port \$/g, ", ")
        //keep these at the bottom
        .replace(/\$,/g, ") {")
        .replace(/\$/g, ")")
        .replace(/end/g, "}")
        .replace(/and/g, ",")
        .replace(/to/g, "=")
    );
  });
}
