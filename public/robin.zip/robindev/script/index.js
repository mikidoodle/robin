const dateFormat = require("./datey.js");
const path = require('path');
const fs = require('fs');

const http = require('http');
const morsey = require('./morsey/morsey.js')
var mcrypt = require('./mihicrypt/encrypt')
var now = new Date();
const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

module.exports.says = function (string) {
  console.log(string);
};

module.exports.adds = function (value, value2) {
  var result = value+value2
  return result
};

module.exports.subtracts = function (value, value2) {
  var result = value - value2
  return result;
};

module.exports.multiplies = function (value, value2) {
  var result = value * value2
  return result
};

module.exports.divides = function (value, value2) {
  var result = value / value2
  return result
};

module.exports.space = function() {
  var result = " "
  return result 
  }
  
  module.exports.start = function(path) {
 console.log('Beep Boop. Pidgon Initiated')
 console.log('v3.2.5 - Thank you for 1 MILLION downloads!')
 console.log('----------------------------------------')

}

module.exports.random = function(min, max) { 
    result = Math.random() * (max - min) + min;
    return result
}

module.exports.roundoff = function(num) {
  result = Math.round(num)
  return result;
}

module.exports.day = function() {
  return dateFormat(now, "dddd");
}
module.exports.monthname = function() {
  return dateFormat(now, "mmmm");
}

module.exports.monthnumber = function() {
  return dateFormat(now, "mm");
}

module.exports.year = function() {
  return dateFormat(now, "yyyy");
}
module.exports.date = function() {
  return dateFormat(now, "dS");
}

module.exports.hour = function() {
  return dateFormat(now, "h");
}

module.exports.minute = function() {
  return dateFormat(now, "mm");
}
module.exports.second = function() {
  return dateFormat(now, "ss");
}
  module.exports.hms = function() {
  return dateFormat(now, "h:MM:ss");
}

module.exports.period = function() {
  return dateFormat(now, "TT");
}


module.exports.server = function(folder, port) {
     
http.createServer(function (req, res) {
  fs.readFile(folder + req.url, function (err,data) {
   if (err) {
      res.writeHead(404);
      res.write('404');
      res.end(JSON.stringify(err));
      return;
    }
    res.writeHead(200);
    res.end(data);
  });
}).listen(port);
}
module.exports.textserver = function(content, port) {
  http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(content);
  res.end();
}).listen(port);
}
module.exports.morseEncode = function(cont) {
  return morsey.encode(cont);
}

module.exports.morseDecode = function(cont) {
  return morsey.decode(cont);
}

module.exports.encrypt = function(cont) {
var key = '2628262';
var cryptoman = mcrypt.create(key);
var encrypted = cryptoman.encrypt(cont); 
return encrypted;
}

module.exports.decrypt = function(cont) {
  var key = '2628262';
var cryptoman = mcrypt.create(key);
var decrypted = cryptoman.decrypt(cont);
return decrypted;
}

module.exports.delay = function(time, func) {
 var then = 'd81004c532fdd152e43db8d70e4fd060a803cc222a3194448cb8d3f8351be028'
  setTimeout(function(){ 
  func(then);}, 
  time);
}

  module.exports.askquestion = function(question, tod) {
    rl.question(question, (answer) => {
  // TDO: Log the answer in a database
  tod(answer)

});
}

module.exports.closequestion = function() {
  rl.close()
}

module.exports.linequestion = function(todo) {
  rl.on('line', answer => {
    todo(answer)
  })
}

 
  