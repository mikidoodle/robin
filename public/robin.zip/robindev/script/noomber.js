const Database = require("./jsondb.js");
var noomber = new Database('./data.json')

module.exports.make = function (noomb, value) {
  noomber.set(noomb, value)
};

  module.exports.take = function(noomb) {
  if(noomber.has(noomb) == true) {
    
     var result = noomber.get(noomb);
     return result;
     
  } else {
    
    console.log(noomb + ' doesn\'t exist:')
    
    }
}

module.exports.stringy = function(type, noomb) {
  if(type == 'variable') {
  if(noomber.has(noomb) == true) {
    
     var result = noomber.get(noomb);
     return result.toString();
     
  } else {
    
    console.log(noomb + ' doesnt exist:')
    
    }
    
    } else if(type == 'normal'){
      return noomb.toString()
    }
}

module.exports.add = function(noomb, value) {
  noomber.add(noomb, value)
} 

module.exports.subtract = function(noomb, value) {
  noomber.subtract(noomb, value)
} 

module.exports.squareroot = function(tosquare) {
  return Math.sqrt(tosquare)
}

module.exports.makelist = function (noomb, value) {
  valarray = value
  noomber.set(noomb, valarray)
};

module.exports.addtolist = function(noomb, value) {
  noomber.push(noomb, value)
}

module.exports.delete = function(noomb) {
  console.log('Beep Boop.' + ' ' + noomb + ' ' + 'has been deleted')
  noomber.delete(noomb)
}

module.exports.erase = function() {
  noomber.clear()
  console.log('Beep Boop. The database has been erased.')
}

module.exports.clear = function() {
  noomber.clear()
  console.log('Beep Boop. The database has been erased.')
}
