 if which node > /dev/null
    then
    echo "Node.js is installed properly"
        echo "Welcome to robin! Please allow a few seconds for robin to install."
echo "function robin() {node --no-deprecation ~/robin/index.js}" >> ~/.bashrc
echo "function robin() {node --no-deprecation ~/robin/index.js}" >> ~/.zshrc
SCRIPT=$(readlink -f "$0")
SCRIPTPATH=$(dirname "$SCRIPT")
cp -r $SCRIPTPATH ~/robin
cp -r $SCRIPTPATH/robin ~/.vscode/extensions
echo "robin has been installed to ~/robin"
echo ".robin VSCode Extension added"
    else
        echo "Node.js is not installed on your machine. Please install node.js by going to https://nodejs.org"
    fi


